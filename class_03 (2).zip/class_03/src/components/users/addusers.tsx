import React, { useState } from "react";
import axios from 'axios';


const AddUser: React.FC = () => {
    const [name, setName] = useState<string>('');
    const [email, setEmail] = useState<string>('');

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        try {
            const newUser = { name, email };
            await axios.post('http://localhost:5000/users', newUser);
            alert('Usuario agregado exitosamente');
            setName('');
            setEmail('');
        } catch (error) {
            console.error('Error al agregar el usuario:', error);
            alert('Error al agregar el usuario');
        }
    };

    return (
        <div className="container">
            <h5>Agregar Usuario</h5>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Nombre:</label>
                    <input 
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)} 
                        required 
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        required 
                    />
                </div>
                <button type="submit">Agregar</button>
            </form>
        </div>
    );
};

export default AddUser;
