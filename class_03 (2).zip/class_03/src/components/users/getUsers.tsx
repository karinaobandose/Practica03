import React, { useEffect, useState } from "react";
import axios from 'axios';
import logo from "../../logo.svg";

const GetUsers: React.FC = () => {
    const [data, setData] = useState<any[]>([]);

    const Obtener = async () => {
        try {
            const response = await axios.get('http://localhost:5000/users');
            const json = response.data; // Suponiendo que `response.data` es el arreglo de usuarios
            setData(json);
        } catch (error) {
            console.error('Error al obtener los usuarios:', error);
        }
    };

    useEffect(() => {
        Obtener();
    }, []);

    return (
        <div>
            <h5>Consumiendo datos de un API-Rest</h5>
            <p>En este ejemplo se muestra como consumir datos de un API-Rest</p>
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item) => (
                        <tr key={item['id']}>
                            <td>{item['id']}</td>
                            <td>{item['name']}</td>
                            <td>{item['email']}</td>
                            <td><img src={logo} width="40" height="40" alt="Logo de la empresa"/></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default GetUsers;
