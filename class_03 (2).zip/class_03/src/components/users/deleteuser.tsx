import React, { useState } from "react";
import axios from 'axios';

const DeleteUser = () => {
    const [userId, setUserId] = useState('');

    const handleDelete = async () => {
        try {
            await axios.delete(`http://localhost:5000/users/${userId}`);
            alert('Usuario eliminado exitosamente');
            setUserId('');
        } catch (error) {
            console.error('Error al eliminar el usuario:', error);
            alert('Error al eliminar el usuario');
        }
    };

    return (
        <div className="container">
            <h5>Eliminar Usuario</h5>
            <div>
                <label>ID del Usuario:</label>
                <input 
                    type="text" 
                    value={userId} 
                    onChange={(e) => setUserId(e.target.value)} 
                    required 
                />
                <button onClick={handleDelete}>Eliminar</button>
            </div>
        </div>
    );
};

export default DeleteUser;
