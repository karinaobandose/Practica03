import React, { useState } from "react";
import axios from 'axios';

const UpdateUser = () => {
    const [userId, setUserId] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');

    const handleUpdate = async () => {
        try {
            const updatedUser = { name, email };
            await axios.put(`http://localhost:5000/users/${userId}`, updatedUser);
            alert('Usuario actualizado exitosamente');
            setUserId('');
            setName('');
            setEmail('');
        } catch (error) {
            console.error('Error al actualizar el usuario:', error);
            alert('Error al actualizar el usuario');
        }
    };

    return (
        <div className="container">
            <h5>Actualizar Usuario</h5>
            <div>
                <label>ID del Usuario:</label>
                <input 
                    type="text" 
                    value={userId} 
                    onChange={(e) => setUserId(e.target.value)} 
                    required 
                />
            </div>
            <div>
                <label>Nombre:</label>
                <input 
                    type="text" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                />
            </div>
            <div>
                <label>Email:</label>
                <input 
                    type="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                />
            </div>
            <button onClick={handleUpdate}>Actualizar</button>
        </div>
    );
};

export default UpdateUser;
