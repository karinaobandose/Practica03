import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//import App from './App';
import ObtenerUsuarios from "./pages/users/listusers";
import AddUser from './components/users/addusers';
import Deleteuser from './components/users/deleteuser';
import UpdateUser from './components/users/update';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
      <div>
          <AddUser />
          <Deleteuser />
          <UpdateUser />
          <ObtenerUsuarios />
      </div>
  </React.StrictMode>
);
