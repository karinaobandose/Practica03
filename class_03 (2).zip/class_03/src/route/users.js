const express = require('express');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

let users = [
    { "id": "1", "name": "Alice Johnson", "email": "alice.johnson@example.com" },
    { "id": "2", "name": "Bob Smith", "email": "bob.smith@example.com" },
    { "id": "3", "name": "Charlie Brown", "email": "charlie.brown@example.com" },
    { "id": "4", "name": "Diana Prince", "email": "diana.prince@example.com" },
    { "id": "5", "name": "Edward Norton", "email": "edward.norton@example.com" }
];

let lastId = 0;

// Función para generar un nuevo ID único
const generateUniqueId = () => {
    let newId = lastId + 1;
    while (users.some(user => user.id === newId.toString())) {
        newId++;
    }
    lastId = newId;
    return newId.toString();
};

// Crear un nuevo usuario
router.post('/', (req, res) => {
    try {
        const { name, email } = req.body;
        const id = generateUniqueId(); // Generar un ID único
        const newUser = { id, name, email };
        users.push(newUser); // Guardar el usuario en memoria
        res.status(201).send(newUser);
    } catch (error) {
        res.status(400).send({ error: 'Error al crear el usuario' });
    }
});

// Obtener todos los usuarios
router.get('/', async (req, res) => {
    try {
        res.status(200).send(users); // Devuelve el arreglo de usuarios
    } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Error al obtener los usuarios' });
    }
});

// Obtener un usuario por ID
router.get('/:id', async (req, res) => {
    try {
        const userId = req.params.id; // Obtén el ID de los parámetros de la ruta
        const user = users.find(user => user.id === userId); // Busca el usuario en el arreglo
        if (!user) {
            return res.status(404).send({ error: 'Usuario no encontrado' });
        }
        res.status(200).send(user);
    } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Error al obtener el usuario' });
    }
});

// Actualizar un usuario por ID
router.put('/:id', async (req, res) => {
    try {
        const userId = req.params.id; // Obtén el ID de los parámetros de la ruta
        const userIndex = users.findIndex(user => user.id === userId); // Busca el índice del usuario en el arreglo
        
        if (userIndex === -1) {
            return res.status(404).send({ error: 'Usuario no encontrado' });
        }
        
        // Actualiza los campos del usuario con los datos proporcionados en el cuerpo de la solicitud
        users[userIndex] = { ...users[userIndex], ...req.body };
        res.status(200).send(users[userIndex]);
    } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Error al actualizar el usuario' });
    }
});

// Eliminar un usuario por ID
router.delete('/:id', async (req, res) => {
    try {
        const userId = req.params.id; // Obtén el ID de los parámetros de la ruta
        const userIndex = users.findIndex(user => user.id === userId); // Busca el índice del usuario en el arreglo
        
        if (userIndex === -1) {
            return res.status(404).send({ error: 'Usuario no encontrado' });
        }
        
        // Elimina el usuario del arreglo
        users.splice(userIndex, 1);
        res.status(200).send({ message: 'Usuario eliminado' });
    } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Error al eliminar el usuario' });
    }
});

module.exports = router;